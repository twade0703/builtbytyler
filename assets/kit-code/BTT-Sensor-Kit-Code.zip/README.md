# BuiltByTyler Sensor Kit: Arduino code for ESP32

One small, working sketch for each of the 37 modules in the kit, written for the
**ESP32-WROOM-32 DevKit V1 (30-pin)** on the **Arduino-ESP32 core 3.x**.
Each sketch reads the module and prints to the Serial Monitor, or drives the output (blink, fade, beep, click).
The wiring is in the comment at the top of every sketch, and every sketch uses the same pin plan as the kit's wiring cards.

## 1. Install the ESP32 board package (once)

1. Install the **Arduino IDE 2** from arduino.cc.
2. **File > Preferences > Additional boards manager URLs**: add
   `https://espressif.github.io/arduino-esp32/package_esp32_index.json`
3. **Tools > Board > Boards Manager**: search **esp32** and install **esp32 by Espressif Systems**, version **3.0 or newer**.
4. **Tools > Board > esp32 > ESP32 Dev Module**, then pick the board's COM port under **Tools > Port**.
   No COM port? Install the USB driver for your board's USB chip: CP210x (Silicon Labs) or CH340 (WCH).

## 2. Install the libraries (only 6 sketches need one)

In **Sketch > Include Library > Manage Libraries**, search for and install:

| Library (search for) | Used by |
|---|---|
| **OneWire** (Paul Stoffregen, 2.3.8+) and **DallasTemperature** (Miles Burton) | S01 |
| **Adafruit ADXL345** (say yes to "install dependencies" for Adafruit Unified Sensor) | S05 |
| **DHT sensor library** (Adafruit, say yes to dependencies) | S11 |
| **IRremote** (Armin Joachimsmeyer, **4.4 or newer**, older versions don't build on ESP32 core 3.x) | S12, S13 |
| **Adafruit ADS1X15** | S38 |

The other 31 sketches use only built-in functions.

## 3. Open and upload a sketch

1. Unzip `BTT-Sensor-Kit-Code.zip`. Keep each `Sxx_...` folder intact: Arduino needs the folder name to match the `.ino` name.
2. **File > Open** the `.ino` file, for example `S07_Alcohol_MQ3/S07_Alcohol_MQ3.ino`.
3. Wire the module as shown in the comment at the top. Do this with the USB cable unplugged.
4. Click **Upload** (the arrow). If it hangs on `Connecting....`, hold the board's **BOOT** button until the upload starts.
5. Open **Tools > Serial Monitor** and set it to **115200 baud**.

## Pin notes for the 30-pin DevKit V1

- Every sketch uses the same pin plan: digital inputs on **GPIO 4** (then 16 and 17, silk RX2/TX2; GPIO 5 is avoided because it is a boot strapping pin), analog on **GPIO 34** (then 35),
  outputs on **GPIO 18**, RGB on **GPIO 25/26/27**, and I2C on **SDA = GPIO 21, SCL = GPIO 22**.
- **GPIO 34 and 35 are input-only** and have no internal pull-up or pull-down. The kit uses them only for analog inputs (AO, X, Y).
- Analog reads are 12-bit (0..4095). `analogReadMilliVolts()` gives calibrated millivolts, so the sketches use it wherever the voltage matters.
  The ESP32 ADC flattens out near 0 V and above ~3.1 V. For precise readings, use S38 (ADS1115).
- **VCC goes to 3V3** for every module except S02, S04, S07 and S22. Those four need 5 V, so connect their **5V** pin to **VIN**,
  which carries 5 V only while the board is powered over USB (or with 5 V on VIN).
  The MQ boards keep their AO and DO outputs under 3.3 V, so they are safe for the ESP32.
- Never put more than 3.3 V on any GPIO.

## The sketches

| Sketch | Module | What it does |
|---|---|---|
| S01_Temp_DS18B20 | DS18B20 1-Wire temperature | Prints degrees C every second (library: OneWire + DallasTemperature) |
| S02_Power_LED | 1 W white LED | Fades the LED up and down with PWM (5 V on VIN) |
| S03_RGB_LED_5mm | 5 mm RGB LED | Cycles colours by mixing PWM on R, G and B |
| S04_Relay | 5 V relay | Clicks the relay on and off every 2 s (low-voltage loads only) |
| S05_Accel_ADXL345 | ADXL345 accelerometer | Prints X, Y, Z in g over I2C at 0x53 (library: Adafruit ADXL345) |
| S06_Buzzer_Active | Active buzzer | Beep, pause, beep-beep |
| S07_Alcohol_MQ3 | MQ-3 alcohol | Prints the AO level and the DO alarm (DO LOW = alcohol detected) |
| S08_Button | 12 mm button | Prints pressed or released (HIGH = pressed) |
| S09_Touch_TTP223 | Capacitive touch | Prints touched or released (HIGH = touched) |
| S10_Crash_Switch | Lever switch | Prints when the lever is hit (HIGH = hit) |
| S11_Temp_Humidity_DHT11 | DHT11 | Prints C and %RH every 2 s (library: DHT sensor library) |
| S12_IR_Receiver | TSOP38238 IR receiver | Decodes any TV remote: protocol, address, command (library: IRremote) |
| S13_IR_Transmitter | 940 nm IR LED | Sends a NEC remote code every 3 s (library: IRremote) |
| S14_Tilt | Ball tilt switch | Prints upright or tilted (HIGH = upright) |
| S15_Bicolor_LED | Red/green LED | Red, green, both, off |
| S16_Hall_Magnet | DRV5033 hall switch | Prints when a magnet is near (LOW = magnet) |
| S17_Joystick | 2-axis joystick | Prints X, Y (0..4095) and the push click (SW LOW = pushed) |
| S18_Knock | Knock switch | Counts knocks |
| S19_Temp_Analog_MCP9700A | MCP9700A analog temp | Prints mV and degrees C: (mV - 500) / 10 |
| S20_Laser | 650 nm laser (Class 2) | Blinks the laser 1 s on, 1 s off. Never aim it at eyes |
| S21_Line_Tracker | TCRT5000 line sensor | Prints AO and line or white (DO HIGH = black line) |
| S22_Gas_MQ2 | MQ-2 gas and smoke | Prints the AO level and the DO alarm (DO LOW = gas detected) |
| S23_Magic_Cup | Tilt switch + LED | Fades the LED in when upright and out when tipped |
| S24_Sound | Microphone + preamp | Sound level % meter, plus a clap detector on DO |
| S25_Obstacle_IR | IR obstacle sensor | Prints AO and obstacle or clear (DO LOW = obstacle) |
| S26_Motion_PIR | AM312 PIR | Prints MOTION or quiet (HIGH = motion) |
| S27_Buzzer_Passive | Passive buzzer | Plays C5-E5-G5-C6 with tone() |
| S28_Photo_Gate | ITR9608 slot sensor | Counts slot blocks per second and RPM (uses an interrupt) |
| S29_Light_LDR | LDR photocell | Prints the light level: AO, mV, dark/room/bright |
| S30_Knob_Pot | 10k potentiometer | Prints AO, mV and % of the knob's turn |
| S31_Pulse | Pulse sensor | Detects heartbeats and prints BPM (not a medical device) |
| S32_RGB_LED_SMD | 5050 SMD RGB LED | Cycles colours by mixing PWM on R, G and B |
| S33_Reed_Switch | Reed switch | Prints closed or open (HIGH = magnet near) |
| S34_Rotary_Encoder | EC11 encoder | Counts clicks in each direction, plus the push button (no library) |
| S35_Light_TEMT6000 | TEMT6000 light sensor | Prints the light level: AO, mV, dark/room/bright |
| S36_Thermistor | 10k NTC thermistor (B3380) | Prints degrees C using the B-equation |
| S38_ADC_ADS1115 | ADS1115 16-bit ADC | Prints A0-A3 in volts over I2C at 0x48 (library: Adafruit ADS1X15) |

S37 (ultrasonic) isn't in this kit yet, so there is no sketch for it.
